from django import forms
class BlogForm(forms.Form):
	sl_no=forms.IntegerField()
	title=forms.CharField(max_length=25)
	body=forms.CharField(max_length=100)
	field_order = ['sl_no','title', 'body']