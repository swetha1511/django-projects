from django.db import models
class BlogPost(models.Model):
	sl_no=models.IntegerField(default=0)
	title=models.CharField(max_length=25)
	body=models.TextField(max_length=100)
	#post_date=models.DateTimeField()
	def __str__(self):
		return self.title