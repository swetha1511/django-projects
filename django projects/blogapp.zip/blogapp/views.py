from datetime import datetime
from django.shortcuts import render
from blogapp.models import BlogPost
from blogapp.forms import BlogForm
from django.http import HttpResponseRedirect
def archive(request):
	posts = BlogPost.objects.all()
	return render(request,'archive.html', {'posts': posts})
def postBlog(request):
	form=BlogForm()
	if request.method == 'POST':
		form = BlogForm(request.POST)
		if form.is_valid():
			sl_no=int(form.cleaned_data['sl_no'])
			title=form.cleaned_data['title']
			body=form.cleaned_data['body']
			time=datetime.now()
			g=BlogPost(sl_no=sl_no,title=title,body=body)
			g.save()
			return HttpResponseRedirect('../')
	return render(request,'create.html', {'form': form})