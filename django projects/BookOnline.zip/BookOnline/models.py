from django.db import models
ROOM_CHOICES =(
    ("1","Standard"),
    ("2","Classic"),
    ("3","Deluxe")
)
class Rooms(models.Model):
    room_type = models.CharField(
        max_length=30,
        choices=ROOM_CHOICES,
        default='Standard'
    )
    available_count = models.IntegerField()
    rate_per_day = models.IntegerField()
    def __str__(self):
        return self.room_type