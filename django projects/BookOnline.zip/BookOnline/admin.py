from django.contrib import admin
from .models import Rooms
@admin.register(Rooms)
class BookAdmin(admin.ModelAdmin):
    list_display=('room_type',)
    list_filter=('room_type',)
    ordering=('available_count',)
    search_fields=('room_type',)