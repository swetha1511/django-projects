from django import forms

from busticket.models import Destinations
class busForm(forms.Form):
    Bus_Number=forms.IntegerField()
    Destination_Place=forms.CharField(max_length=20)
    No_of_Persons=forms.IntegerField()
    field_order=['Bus_Number','Destination_Place','No_of_Persons']