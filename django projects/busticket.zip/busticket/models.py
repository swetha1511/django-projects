from django.db import models
class Destinations(models.Model):
    Destination_cities=models.CharField(max_length=20)
    Ticket_Cost=models.IntegerField()
    def __str__(self):
        return self.Destination_cities+' -> '+str(self.Ticket_Cost)
class BusDetails(models.Model):
    Bus_No=models.IntegerField()
    Departure_Date=models.DateField()
    Departure_Time=models.TimeField()
    Seats_Avaliable=models.IntegerField()
    Destination=models.ForeignKey(Destinations,on_delete=models.CASCADE,)
    def __str__(self):
        return str(self.Bus_No)