from django.urls import path
from . import views
urlpatterns=[
    path('',views.display,name='display'),
    path('bus/',views.bookTicket,name='bookTicket')
]