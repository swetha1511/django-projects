from django.contrib import admin
from .models import BusDetails
@admin.register(BusDetails)
class BusDetailsAdmin(admin.ModelAdmin):
    list_display=('Bus_No','Departure_Time')
    list_filter=('Departure_Date',)
    ordering=('Departure_Time',)
    search_fields=('Bus_No',)
'''@admin.register(Destinations)
class DestinationsAdmin(admin.ModelAdmin):
    list_display=('Destination_cities',)
    list_filter=('Ticket_Cost',)
    ordering=('Ticket_Cost',)
    search_fields=('Destination_cities',)'''