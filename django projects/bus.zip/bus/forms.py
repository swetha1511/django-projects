from django import forms
class busForm(forms.Form):
    Bus_Number=forms.CharField()
    Destination_Place=forms.CharField()
    No_of_Persons=forms.IntegerField()
    field_order=['Bus_Number','Destination_Place','No_of_Persons']