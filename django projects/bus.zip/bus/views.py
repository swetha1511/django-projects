from django.http import HttpResponse
from django.shortcuts import render
from .models import BusDetails
from .forms import busForm
def display(request):
    form=BusDetails.objects.all()
    return render(request,'traveldetails.html',{'form':form})
def bookTicket(request):
    list1=[]
    form=busForm()
    if request.method=='POST':
        form=busForm(request.POST)
        if form.is_valid():
            busno=form.cleaned_data['Bus_Number']
            dest=form.cleaned_data['Destination_Place']
            no_of_seats=form.cleaned_data['No_of_Persons']
            q=BusDetails.objects.get(Bus_No=busno)
            list1=q.Destination.split(',')
            if dest in list1:
                seats=q.Seats_Avaliable
                if seats>=no_of_seats:
                    q.Seats_Avaliable=seats-no_of_seats
                    q.save()
                    return HttpResponse('Tickets Booked successfully')
                else:
                    return HttpResponse('No empty seats avaliable')
    return render(request,'bus.html',{'form':form})