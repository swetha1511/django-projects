from django.db import models
'''class Destinations(models.Model):
    Destination_cities=models.CharField(max_length=20)
    Ticket_Cost=models.IntegerField()
    def __str__(self):
        return self.Destination_cities+' -> '+str(self.Ticket_Cost)'''
class BusDetails(models.Model):
    Bus_No=models.CharField(max_length=5)
    Departure_Date=models.DateField()
    Departure_Time=models.TimeField()
    Seats_Avaliable=models.IntegerField()
    Destination=models.CharField(max_length=100)
    Ticket_Cost=models.IntegerField()
    def __str__(self):
        return self.Bus_No